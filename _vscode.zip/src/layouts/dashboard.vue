<script setup>
import Header from "@/components/layout/dashboard/Header.vue";
import Sidebar from "@/components/layout/dashboard/Sidebar.vue";
</script>
<template>
  <div class="flex h-screen w-screen">
    <Sidebar class="fixed top-0 z-50" />
    <div class="flex h-full w-full flex-col">
      <Header />
      <div class="h-full bg-[#F5F7FA] p-4">
        <slot />
      </div>
    </div>
  </div>
</template>
