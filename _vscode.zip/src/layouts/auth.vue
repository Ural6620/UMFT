<template>
  <div>
    <RouterView />
  </div>
</template>
