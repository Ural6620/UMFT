import { lazyLoad, layoutSetter } from "@/utils/routerUtils.js";

const links = [
  {
    path: "/show/:id",
    name: "show/:id",
    component: () => lazyLoad("show"),
    meta: {
      title: "Show Id",
    },
  },
];
layoutSetter(links, "show");
export default links;