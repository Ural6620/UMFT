import { useAuthStore } from "@/stores/auth";

export async function mainGuard(to, from) {
  const authStore = useAuthStore();
  const token = authStore.$state.token;
  if (to.path === '/show/:id') {
    return { name: "show/:id" };
  }
  if (!token && to.name !== "login") {
    return { name: "login" };
  }
  return true;
}
