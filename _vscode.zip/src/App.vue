<script setup>
import Controller from "@/layouts/controller.vue";
</script>
<template>
  <Controller>
    <RouterView />
  </Controller>
</template>
