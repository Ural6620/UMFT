<script setup>
import { useRouter, useRoute } from 'vue-router';
const route = useRoute();
const router = useRouter();
const id = route.params.id
</script>
<template>
  <div>show {{ id }}</div>
</template>