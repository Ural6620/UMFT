<template>
  <form>
    <slot />
  </form>
</template>
