<template>
  <button class="rounded-md px-4 py-1.5 bg-green-100 transition ease-linear duration-300 hover:bg-green-300">
    <slot />
  </button>
</template>
