<script setup>
import { onMounted, reactive } from 'vue';
import BaseInput from '../form/BaseInput.vue';
import SelectFilial from '../form/SelectFilial.vue';
import { useProductStore } from '@/stores/product';
import BaseButton from './BaseButton.vue';

const productStore = useProductStore();
const data = reactive({
  product: "",
  count: 0,
  per_price: 0,
  total_price: 0
});

onMounted(() => {
  productStore.get()
})

</script>
<template>
  <div class="w-full grid grid-cols-9 gap-4 items-center">

  </div>
</template>